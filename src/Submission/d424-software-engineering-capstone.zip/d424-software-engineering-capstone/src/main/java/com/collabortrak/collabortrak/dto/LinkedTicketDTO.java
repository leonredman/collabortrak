package com.collabortrak.collabortrak.dto;

public class LinkedTicketDTO {
}
