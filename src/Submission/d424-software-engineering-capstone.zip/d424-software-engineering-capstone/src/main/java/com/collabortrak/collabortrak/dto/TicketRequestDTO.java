package com.collabortrak.collabortrak.dto;

public class TicketRequestDTO {
    public String title;
    public String description;
    public String status;
    public String priority;
    public String category;
    public Long linkedEpicId;
    public Long customerId;
    public Long assignedEmployeeId;
    public String ticketType;
}
