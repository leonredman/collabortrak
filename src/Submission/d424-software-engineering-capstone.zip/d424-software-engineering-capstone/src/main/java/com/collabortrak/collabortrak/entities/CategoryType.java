package com.collabortrak.collabortrak.entities;

public enum CategoryType {
    NEW_BUILD,
    REVISIONS,
    POST_PUBLISH,
    BUG
}
