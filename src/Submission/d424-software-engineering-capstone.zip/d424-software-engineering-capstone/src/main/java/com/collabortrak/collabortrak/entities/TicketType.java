package com.collabortrak.collabortrak.entities;

public enum TicketType {
    EPIC,
    STORY,
    TASK,
    BUG
}
