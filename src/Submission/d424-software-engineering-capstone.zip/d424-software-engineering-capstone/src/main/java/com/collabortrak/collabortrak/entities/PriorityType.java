package com.collabortrak.collabortrak.entities;

public enum PriorityType {
    LOW,
    MEDIUM,
    HIGH
}
