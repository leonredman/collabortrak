package com.collabortrak.collabortrak.entities;

public enum PlanType {
    STANDARD,
    PREMIUM,
    WOO_COMMERCE
}
