package com.collabortrak.collabortrak.entities;

public enum RoleType {
    ADMIN,
    MANAGER,
    WEBSITE_SPECIALIST,
    DEVELOPER,
    QA_AGENT
}
