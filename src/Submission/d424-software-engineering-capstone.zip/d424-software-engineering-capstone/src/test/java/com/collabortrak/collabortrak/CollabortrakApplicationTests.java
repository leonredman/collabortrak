package com.collabortrak.collabortrak;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


public class CollabortrakApplicationTests {
    @Test
    void contextLoads() {
    }
}
